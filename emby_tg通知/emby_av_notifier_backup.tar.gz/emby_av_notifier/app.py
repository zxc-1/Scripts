import os
import re
from typing import Optional, Dict, Any, List

from fastapi import FastAPI, Request
from fastapi.responses import PlainTextResponse
import httpx

app = FastAPI()

# 环境变量
TG_BOT_TOKEN = os.getenv("TG_BOT_TOKEN")
TG_CHAT_ID = os.getenv("TG_CHAT_ID")
EMBY_BASE_URL = os.getenv("EMBY_BASE_URL", "").rstrip("/")
TMDB_API_KEY = os.getenv("TMDB_API_KEY")
EMBY_API_KEY = os.getenv("EMBY_API_KEY")

# 番号正则：ABP-123 / abp123 / SIRO-1234 等
CODE_PATTERN = re.compile(r"([A-Za-z]{2,6})[-_]?(\d{3,5})", re.IGNORECASE)


def extract_code(text: str) -> Optional[str]:
    """从文本中提取番号，比如 ABP-123、ABP123、SIRO-1234"""
    if not text:
        return None
    m = CODE_PATTERN.search(text)
    if not m:
        return None
    pre, num = m.groups()
    return f"{pre.upper()}-{num}"


def fmt_size(size_bytes: Optional[int]) -> Optional[str]:
    if not size_bytes or size_bytes <= 0:
        return None
    kb = size_bytes / 1024
    mb = kb / 1024
    gb = mb / 1024
    if gb >= 1:
        return f"{gb:.2f} GB"
    if mb >= 1:
        return f"{mb:.2f} MB"
    return f"{kb:.2f} KB"


def extract_emby_metadata(item: dict) -> Dict[str, Any]:
    """
    从 Emby 的 Item 里拿已经刮好的数据（适用于 .nfo + poster 结构）
    包含：简介 / 标签 / 演员 / 首播日期或年份
    """
    meta: Dict[str, Any] = {}

    overview = item.get("Overview")
    if overview:
        meta["desc"] = overview

    genres = item.get("Genres")
    if genres:
        meta["tags"] = genres

    people = item.get("People") or []
    actresses = [p.get("Name") for p in people if p.get("Type") in ("Actor", "GuestStar", "Director")]
    if actresses:
        meta["actresses"] = actresses

    premiere = item.get("PremiereDate")
    year = item.get("ProductionYear")
    if premiere:
        meta["release_date"] = str(premiere).split("T")[0]
    elif year:
        meta["release_date"] = str(year)

    return meta


async def fetch_tmdb_info(title: str, year: Optional[int], media_type: str) -> Optional[Dict[str, Any]]:
    """
    普通影视：用 TMDB 搜索补充信息（标题／简介／评分／海报）
    """
    if not TMDB_API_KEY or not title:
        print("TMDB_API_KEY 未设置或标题为空，跳过 TMDB 查询")
        return None

    base = "https://api.themoviedb.org/3"
    params = {"api_key": TMDB_API_KEY, "query": title, "language": "zh-CN"}

    if year:
        if media_type.lower() == "movie":
            params["year"] = year
        else:
            params["first_air_date_year"] = year

    endpoint = "/search/movie" if media_type.lower() == "movie" else "/search/tv"

    try:
        async with httpx.AsyncClient(timeout=8.0) as client:
            resp = await client.get(base + endpoint, params=params)
            print("TMDB 响应状态:", resp.status_code)
            if resp.status_code != 200:
                print("TMDB 返回异常:", resp.text)
                return None
            data = resp.json()
            results = data.get("results") or []
            if not results:
                print("TMDB 未找到结果")
                return None
            m0 = results[0]
            meta: Dict[str, Any] = {
                "title": m0.get("title") or m0.get("name"),
                "desc": m0.get("overview"),
                "release_date": m0.get("release_date") or m0.get("first_air_date"),
                "score": m0.get("vote_average"),
            }
            # 先尝试 TMDB 横图 fanart
            backdrop_path = m0.get("backdrop_path")
            if backdrop_path:
               meta["cover_url"] = f"https://image.tmdb.org/t/p/w1280{backdrop_path}"
            else:
                # 没 fanart 就退回 TMDB 海报
                poster_path = m0.get("poster_path")
                if poster_path:
                   meta["cover_url"] = f"https://image.tmdb.org/t/p/w500{poster_path}"
            return meta
    except Exception as e:
        print("TMDB 查询异常:", e)
        return None


async def send_telegram_message(text: str, photo_url: Optional[str] = None) -> None:
    """
    推送到 Telegram：
    - 有 photo_url：在内存里从 URL 拉图片，再 sendPhoto 上传
    - 失败 / 没图：降级成 sendMessage 纯文字
    """

    if not TG_BOT_TOKEN or not TG_CHAT_ID:
        print("TG_BOT_TOKEN 或 TG_CHAT_ID 未设置，无法推送")
        return

    api_base = f"https://api.telegram.org/bot{TG_BOT_TOKEN}"
    print(">>> send_telegram_message start")
    print("chat_id =", TG_CHAT_ID, "photo_url =", photo_url)

    # 先尝试带图片
    if photo_url:
        try:
            async with httpx.AsyncClient(timeout=20.0) as client:
                print("从封面 URL 拉取图片:", photo_url)
                img_resp = await client.get(photo_url)
                print("image status:", img_resp.status_code,
                      "ct:", img_resp.headers.get("content-type"))

                ct = img_resp.headers.get("content-type") or ""
                if img_resp.status_code == 200 and ct.startswith("image"):
                    img_bytes = img_resp.content
                    files = {
                        "photo": ("cover.jpg", img_bytes, ct)
                    }
                    data = {
                        "chat_id": TG_CHAT_ID,
                        "caption": text,
                        "parse_mode": "Markdown",
                    }
                    resp = await client.post(f"{api_base}/sendPhoto",
                                             data=data, files=files)
                    print("TG sendPhoto status:", resp.status_code)
                    print("TG sendPhoto body:", resp.text)

                    ok = False
                    try:
                        body = resp.json()
                        ok = body.get("ok", False)
                    except Exception as e:
                        print("解析 sendPhoto 返回 JSON 出错:", repr(e))

                    if ok:
                        print("sendPhoto ok，结束")
                        return
                    else:
                        print("sendPhoto 返回非 ok，准备降级为纯文字")
                else:
                    print("图片响应不是 200 或不是 image/*，不尝试 sendPhoto")

        except Exception as e:
            print("sendPhoto 阶段异常:", repr(e))

    # 走到这里：要么没图，要么 sendPhoto 失败 → 纯文字
    try:
        print("发送纯文本消息")
        async with httpx.AsyncClient(timeout=20.0) as client:
            resp2 = await client.post(
                f"{api_base}/sendMessage",
                data={
                    "chat_id": TG_CHAT_ID,
                    "text": text,
                    "parse_mode": "Markdown",
                },
            )
        print("TG sendMessage status:", resp2.status_code)
        print("TG sendMessage body:", resp2.text)
    except Exception as e:
        print("sendMessage 阶段异常:", repr(e))


from datetime import datetime

@app.post("/emby-webhook", response_class=PlainTextResponse)
async def emby_webhook(request: Request):
    data = await request.json()
    # EventName 不可靠，只当日志用；真正判断只看 Item 是否存在
    event = data.get("EventName") or data.get("NotificationType") or data.get("Name") or ""
    item = data.get("Item") or {}

    print("========== WEBHOOK ==========")
    print("EventName:", event)
    print("ItemName:", item.get("Name"))
    print("Full path:", item.get("Path"))

    if not item:
        print("没有 Item 字段，忽略这条 Webhook")
        return "IGNORED"

    name = item.get("Name", "") or ""
    media_type = item.get("Type", "Video") or "Video"
    item_id = item.get("Id")
    path = item.get("Path", "") or ""

    # 时长
    ticks = item.get("RunTimeTicks") or 0
    duration_sec = int(ticks // 10_000_000) if ticks else 0
    duration_min = duration_sec // 60 if duration_sec else 0

    # 大小 / 分辨率
    media_sources: List[Dict[str, Any]] = item.get("MediaSources") or []
    size_str = None
    resolution_str = None
    if media_sources:
        ms0 = media_sources[0]
        size_str = fmt_size(ms0.get("Size"))
        width = ms0.get("Width")
        height = ms0.get("Height")
        if width and height:
            resolution_str = f"{width}×{height}"

    # 番号判断：路径或标题里能匹配就算番号
    code = extract_code(path) or extract_code(name)
    is_av = code is not None
    print("是否识别为番号:", is_av, "番号:", code)

    # Emby 封面 URL：改成用 Backdrop（fanart.jpg），带 api_key + 缩放
    emby_cover_url = None
    if EMBY_BASE_URL and item_id:
        if EMBY_API_KEY:
            emby_cover_url = (
                f"{EMBY_BASE_URL}/Items/{item_id}/Images/Backdrop"
                f"?api_key={EMBY_API_KEY}&maxWidth=400&quality=80"
            )
        else:
            emby_cover_url = f"{EMBY_BASE_URL}/Items/{item_id}/Images/Backdrop"
    print("Emby 封面地址:", emby_cover_url)

    # Emby 刮削 metadata（适用于你的 .strm + .nfo 方案）
    local_meta = extract_emby_metadata(item)
    print("从 Emby 提取的 meta:", local_meta)

    # 普通影视：尝试 TMDB 补充信息
    tmdb_meta: Optional[Dict[str, Any]] = None
    if not is_av:
        year = item.get("ProductionYear")
        tmdb_meta = await fetch_tmdb_info(name, year, media_type)
        print("TMDB meta:", tmdb_meta)

    # 合并 meta：先用 Emby 的，再用 TMDB 补缺
    meta: Dict[str, Any] = {}
    for src in (local_meta, tmdb_meta):
        if not src:
            continue
        for k, v in src.items():
            if v and k not in meta:
                meta[k] = v

    # ========= 拼装消息文本 =========
    lines: List[str] = []

    # 入库时间（没有就用当前时间）
    added_raw = item.get("DateCreated") or item.get("DateAdded")
    if added_raw:
        added_str = str(added_raw).split(".")[0].replace("T", " ")
    else:
        added_str = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")

    # 顶部标题行
    if is_av and code:
        lines.append(f"📀 新片入库  {code}")
    else:
        lines.append("📀 新影视入库")

    lines.append("")  # 空一行更舒服

    # 基本信息块
    if name:
        safe_name = name.replace("[", "【").replace("]", "】")
        lines.append(f"📛 标题：{safe_name}")

    if is_av and code:
        lines.append(f"🔖 番号：{code}")

    if media_type:
        lines.append(f"📂 类型：{media_type}")

    release_date = meta.get("release_date")
    if release_date:
        lines.append(f"📅 发行日期：{release_date}")

    if added_str:
        lines.append(f"🕒 入库时间：{added_str}")

    if resolution_str:
        lines.append(f"💎 分辨率：{resolution_str}")

    if duration_min:
        lines.append(f"⏱ 时长：{duration_min} 分钟")

    if size_str:
        lines.append(f"💾 大小：{size_str}")

    actresses = meta.get("actresses")
    if actresses:
        lines.append("👤 演员：" + "、".join(actresses))

    tags = meta.get("tags")
    if tags:
        lines.append("🏷 标签：" + " / ".join(tags))

    score = meta.get("score")
    if isinstance(score, (int, float)):
        lines.append(f"⭐ 评分：{score:.1f}")

    # 简介块
    desc = meta.get("desc")
    if desc:
        lines.append("")
        d = str(desc)
        if len(d) > 200:
            d = d[:200] + "..."
        lines.append("📖 简介：")
        lines.append(d)

    # 这里不再追加底部的 #标签 行，已经在上面 “🏷 标签：” 展示过了

    text = "\n".join(lines)

    # 封面优先顺序：
    #   非番号：先 TMDB 封面，再 Emby 封面
    #   番号：直接用 Emby 封面
    cover_url = None
    if not is_av and tmdb_meta and tmdb_meta.get("cover_url"):
        cover_url = tmdb_meta["cover_url"]
    else:
        cover_url = emby_cover_url

    print("最终封面 URL:", cover_url)
    print("准备推送的文本:\n", text)

    await send_telegram_message(text, cover_url)
    print("推送逻辑执行完毕")

    return "OK"


@app.get("/", response_class=PlainTextResponse)
async def root():
    return "Emby AV + TMDB Notifier is running."